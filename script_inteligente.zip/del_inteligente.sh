#!/bin/sh

# Script inteligente borrado de imagenes
#
# Para mas informacion grupo telegram: https://t.me/joinchat/AFo2KEfzM5Tk7y3VgcqIOA
#
# AUTOR: jungle-team

dispositvo="hdd"
dias="7"

echo "########################################"
echo "#Borrando inteligentemente archivos....#"
echo "########################################"

find /media/$dispositvo/xtraEvent/poster/ -type f -mtime +$dias -delete
find /media/$dispositvo/xtraEvent/banner/ -type f -mtime +$dias -delete
find /media/$dispositvo/xtraEvent/backdrop/ -type f -mtime +$dias -delete


